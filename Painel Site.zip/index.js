const link = 'http://localhost:80/'//'https://smoretti.squareweb.app/'

async function wait(ms) {
    return new Promise(result => setTimeout(result, ms))
}
const pago_cor = 'rgb(53, 255, 53)'
const pendente_cor = 'rgb(237, 243, 55)'
window.onload = async () => {
    const gerar_pago = (nome, valor) => {
        const h1 = document.createElement("h1")
    }
    document.querySelector("#painel").style.opacity = '0'
    await wait(100)
    document.querySelector("#painel").style.transition = '1s'

    function carregando() {
        document.querySelector("#progress-bar").classList.add("carregando")
    }
    function naocarregando() {
        document.querySelector("#progress-bar").classList.remove("carregando")
    }
    function add_0(num) {
        if (String(num).length == 1) {
            return `0${num}`
        } else {
            return num
        }
    }
    function esta_valido(data, dataLimite) {
        if (data == dataLimite) {
            return false
        }
        var partesData = data.split('/');
        var dataAtual = new Date(partesData[2], partesData[1] - 1, partesData[0]);
        var partesDataLimite = dataLimite.split('/');
        var dataLimite = new Date(partesDataLimite[2], partesDataLimite[1] - 1, partesDataLimite[0]);


        var hoje = new Date();


        if (hoje >= dataAtual && hoje <= dataLimite) {
            return true;
        } else {
            return false;
        }
    }
    function minha_data() {
        const data = new Date()
        return `${add_0(data.getDate())}/${add_0(data.getMonth() + 1)}/${data.getFullYear()}`
    }
    function pegar_daqui_tal_mes(meses) {
        var hoje = new Date();
        hoje.setMonth(hoje.getMonth() + meses);
        var dia = hoje.getDate();
        var mes = hoje.getMonth() + 1;
        var ano = hoje.getFullYear();
        dia = (dia < 10 ? '0' : '') + dia;
        mes = (mes < 10 ? '0' : '') + mes;
        return dia + "/" + mes + "/" + ano;
    }
    let continuar = false
    const entrar = document.querySelector("#entrar")
    const old_title = document.title
    title("Painel - Login")
    function title(n) {
        document.title = n
    }
    function progresso() {
        document.body.style.cursor = "progress"
        entrar.style.cursor = "progress"
    }
    function pararprogresso() {
        document.body.style.cursor = "auto"
        entrar.style.cursor = "pointer"
    }
    let tab
    let automatico = false
    document.querySelector("#olho").addEventListener("click", () => {
        if (document.querySelector("#senha_input").type == 'text') {
            document.querySelector("#senha_input").type = 'password'
            document.querySelector("#olho").src = './olho2.png'
        } else {
            document.querySelector("#senha_input").type = 'text'
            document.querySelector("#olho").src = './olho.png'
        }
    })
    entrar.addEventListener("click", async () => {
        title("Entrando...")
        carregando()
        progresso()
        const login = document.querySelector("#login_input").value
        const senha = document.querySelector("#senha_input").value


        if (login.length == 0) {
            document.querySelector("#title2").textContent = "Login vazio!"
            naocarregando()
            await wait(1000)
            document.querySelector("#title2").textContent = "Login"
            title(old_title)
            pararprogresso()
            return
        }

        if (senha.length == 0) {
            document.querySelector("#title2").textContent = "Senha vazia!"
            naocarregando()
            await wait(1000)
            document.querySelector("#title2").textContent = "Login"
            title(old_title)
            pararprogresso()
            return
        }
        let erro = false
        let response = await (await fetch(
            link + 'login',
            {
                headers: {
                    'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify({
                    login: login,
                    senha: senha,
                    automatico: automatico
                })
            }
        ).catch(() => {
            erro = true
            alert("Api offline")
        }))
        if (erro == false) {
            response = await response.json()
        }
        if (erro == true) {
            naocarregando()
            pararprogresso()
            title(old_title)
            return
        }

        if (response.sucess == false) {
            document.querySelector("#title2").textContent = "Login ou senha incorreto!"
            naocarregando()
            await wait(700)
            document.querySelector("#title2").textContent = "Login"
            title(old_title)
            pararprogresso()
            return
        }

        if (response.sucess == true) {
            continuar = true
            tab = [senha, response.user, login]
        }
    })

    if (localStorage.getItem('login_e_senha') !== null && localStorage.getItem('login_e_senha') !== 'null') {
        automatico = true
        const a = JSON.parse(localStorage.getItem('login_e_senha'))

        document.querySelector("#login_input").value = a[2]
        document.querySelector("#senha_input").value = a[0]



        document.querySelector("#entrar").click()
    }

    while (true) {
        await wait(10)
        if (continuar == true) {
            break
        }
    }

    localStorage.setItem('login_e_senha', JSON.stringify(tab))
    if (automatico == false) {
        document.querySelector("#titulo3").style['opacity'] = '0'
        document.querySelector("#titulo3").style.transition = '2s'
        await wait(10)
        document.querySelector("#titulo3").textContent = `Olá, ${tab[1]}! Seja bem-vindo(a)!`
        document.querySelector("#titulo3").style['opacity'] = '1'
        pararprogresso()
        naocarregando()
        title(old_title)
        await wait(1000)
        document.querySelector("#login").style.transition = '2s'
        document.querySelector("#login").style.opacity = '0'
        await wait(1500)
        document.querySelector("#painel").style.opacity = '1'
        await wait(500)
    } else {
        pararprogresso()
        naocarregando()
        title(old_title)
        document.querySelector("#painel").style.opacity = '1'
    }
    document.body.removeChild(document.querySelector("#login"))





    let aberto = false
    document.querySelector("#menu").addEventListener("click", async () => {
        if (aberto == false) {
            document.querySelector("#mobile-menu").style.transition = 'none'
            document.querySelector("#mobile-menu").style.display = 'block'
            document.querySelector("#mobile-menu").style.opacity = '0'
            await wait(1)
            document.querySelector("#mobile-menu").style.transition = '200ms'
            document.querySelector("#mobile-menu").style.opacity = '1'
            await wait(1)
            aberto = true
        }
    })
    document.body.addEventListener("click", async () => {
        if (aberto == true) {
            aberto = false
            document.querySelector("#mobile-menu").style.opacity = '0'
            await wait(200)
            document.querySelector("#mobile-menu").style.display = 'none'
        }
    })

    async function reload() {
        document.querySelector("#mensalidades").innerHTML = '<img id="adicionar_novo" src="./botao-adicionar.png">'
        let response = await fetch(link + 'mensalidade', { method: 'GET', headers: { "Content-Type": "application/json" } }).catch(() => {
            alert("Api offline")
            return
        })
        response = await response.json()


        for (const v of response) {
            var divUsuario = document.createElement("div");
            divUsuario.id = "usuario";


            var spanInfo = document.createElement("span");
            spanInfo.id = "info";
            spanInfo.innerHTML = `${v[0]} ➨\n ${v[1][1][1]}`;
            divUsuario.appendChild(spanInfo);


            var divValores = document.createElement("div");
            divValores.id = "valores";

            for (const [i2, v2] of Object.entries(v[1][0][1])) {
                var h1Pendente = document.createElement("h1");
                h1Pendente.textContent = `${i2} ➨ ${v2}`;
                var strongPendente = document.createElement("strong");
                strongPendente.textContent = "PAGO";
                strongPendente.style.color = pago_cor
                strongPendente.style.textAlign = "right";
                h1Pendente.appendChild(strongPendente);
                divValores.appendChild(h1Pendente);
            }

            if (v[2].length !== 0) {
                if (esta_valido(minha_data(), v[2]) == true) {
                    var h1Pendente = document.createElement("h1");
                    h1Pendente.textContent = `${v[2]} ➨ N/A`;
                    var strongPendente = document.createElement("strong");
                    strongPendente.textContent = "P/ mês";
                    strongPendente.style.color = 'rgb(200, 0, 0)'
                    strongPendente.style.textAlign = "right";
                    h1Pendente.appendChild(strongPendente);
                    divValores.appendChild(h1Pendente);
                } else {
                    var h1Pendente = document.createElement("h1");
                    h1Pendente.textContent = `${v[2]} ➨ N/A`;
                    var strongPendente = document.createElement("strong");
                    strongPendente.textContent = "PENDENTE";
                    strongPendente.style.color = pendente_cor
                    strongPendente.style.textAlign = "right";
                    h1Pendente.appendChild(strongPendente);
                    divValores.appendChild(h1Pendente);
                }
            }

            var imgCobrar = document.createElement("img");
            imgCobrar.id = "cobrar_usuario";
            imgCobrar.src = "./dolar.png";

            var imgAdicionar = document.createElement("img");
            imgAdicionar.id = "adicionar";
            imgAdicionar.src = "./botao-adicionar.png";

            var imgRemover = document.createElement("img");
            imgRemover.id = "remover_usuario";
            imgRemover.src = "./remover.png";

            divValores.appendChild(imgCobrar)
            divValores.appendChild(imgAdicionar);
            divValores.appendChild(imgRemover);

            divUsuario.appendChild(divValores);

            document.querySelector("#mensalidades").appendChild(divUsuario)

            imgAdicionar.addEventListener("click", async () => {
                const form = document.querySelector("#formulario").cloneNode(true)
                document.body.appendChild(form)
                form.style.transition = '200ms ease-in-out'
                await wait(1)
                form.style.opacity = '1'

                let nome_ = v[0].split(" ")
                if (nome_.length == 1) {
                    nome_ = nome_[0]
                } else if (nome_.length == 2) {
                    nome_ = `${nome_[0]} ${nome_[1].substring(0, 1)}.`
                } else if (nome_.length >= 3) {
                    nome_ = `${nome_[0]} ${nome_[1].substring(0, 1)} ${nome_[2].substring(0, 1)}.`
                }
                form.querySelector("#form_titulo").innerHTML = nome_
                form.style["pointer-events"] = 'initial'
                //Continuar aqui

                const data = form.querySelector("#data")
                const valor = form.querySelector("#valor")

                let continuar = false
                let cancelar = false
                let valor_auxiliar = 0
                form.querySelector("#fechar_form").addEventListener("click", async () => {
                    cancelar = true
                    await wait(1)
                    continuar = true
                })
                form.querySelector("#confirmar").addEventListener("click", () => {
                    continuar = true
                })

                let calcular = true
                form.querySelector("#auxiliar").addEventListener("click", async () => {
                    calcular = false
                    valor_auxiliar = form.querySelector('#valor').value / 2
                    form.querySelector('#valor').value = form.querySelector('#valor').value / 2
                    await wait(1000)
                    calcular = true
                })

                form.querySelector("#valor").focus()
                while (true) {
                    if (continuar == true) {
                        break
                    }

                    if (valor.value.length !== 0) {
                        const num = Number(valor.value)
                        const old = num
                        if (num) {
                            if (num >= 45) {
                                carregando()
                                let response = await fetch(link + 'mensalidade_valor', {
                                    headers: { "Content-Type": "application/json" },
                                    method: "POST",
                                    body: JSON.stringify({ valor: num })
                                }).catch(() => {
                                    naocarregando()
                                    return alert("Api offline")
                                })
                                naocarregando()
                                response = await response.json()

                                if (response.test.includes("Ilimitada") == true) {
                                    const data_ = new Date()
                                    const tempo = 1
                                    data.value = pegar_daqui_tal_mes(tempo)
                                } else if (response.test.includes("Mensal") == true) {
                                    const data_ = new Date()
                                    const tempo = 1
                                    data.value = pegar_daqui_tal_mes(tempo)
                                } else if (response.test.includes("Trimestral") == true) {
                                    const data_ = new Date()
                                    const tempo = 3
                                    data.value = pegar_daqui_tal_mes(tempo)
                                } else if (response.test.includes("Semestral") == true) {
                                    const data_ = new Date()
                                    const tempo = 6
                                    data.value = pegar_daqui_tal_mes(tempo)
                                } else {

                                }
                            }
                        } else {
                            valor.value = 0
                        }
                        while (true) {
                            if (continuar == true) {
                                break
                            }
                            if (Number(valor.value) !== old && Number(valor.value) !== valor_auxiliar) {
                                break
                            }
                            await wait(1)
                        }
                    }
                    await wait(100)
                }

                form.style.opacity = '0'
                form.style["pointer-events"] = 'initial'
                await wait(200)
                document.body.removeChild(form)
                if (cancelar == true) {
                    return
                }

                const expira = data.value

                if (expira.split("/").length !== 3) {
                    return alert("Dados incorretos.")
                }

                const dias = expira.split("/")

                const numero = v[1][2][1]
                const nome = v[0]
                const modalidade = v[1][1][1]
                const pago = Number(valor.value)

                if (!pago) {
                    return alert("Valor inválido, correto: 10")
                }

                carregando()
                await fetch(link + 'mensalidade_adicionar', {
                    headers: { 'Content-Type': 'application/json' },
                    method: "POST",
                    body: JSON.stringify({ nome: nome, numero: numero, modalidade: modalidade, expira: expira, valor: pago })
                }).catch(() => {
                    alert("Api offline.")
                })
                naocarregando()
                reload()
            })

            imgRemover.addEventListener("click", async () => {
                if (confirm("Deseja excluir mesmo?") == true) {
                    const numero = v[1][2][1]
                    const nome = v[0]
                    const modalidade = v[1][1][1]
                    carregando()
                    await fetch(link + 'excluir_usuario', {
                        headers: { 'Content-Type': 'application/json' },
                        method: "POST",
                        body: JSON.stringify({ nome: nome, numero: numero, modalidade: modalidade })
                    }).catch(() => {
                        alert("Api offline.")
                    })
                    naocarregando()
                    reload()
                }
            })

            imgCobrar.addEventListener("click", async () => {
                if (confirm("Deseja cobrar mesmo?") == true) {
                    const numero = v[1][2][1]
                    const nome = v[0]
                    const modalidade = v[1][1][1]
                    carregando()
                    await fetch(link + 'cobrar', {
                        headers: { 'Content-Type': 'application/json' },
                        method: "POST",
                        body: JSON.stringify({ nome: nome, numero: numero, modalidade: modalidade })
                    }).catch(() => {
                        alert("Api offline.")
                    })
                    naocarregando()
                }
            })
        }

    }

    reload()

    document.querySelector("#adicionar_novo").addEventListener("click", async () => {
        const nome = prompt("Digite o Nome Completo", "Samuel")
        let numero = prompt("Número do whatsapp (5519983611134 / 19983611134)", "5519983611134")
        const modalidade = prompt("Modalidade", 'Kung-Fu, Condicionamento Físico')
        function verificar(test) {
            for (v of test) {
                if (v == null || v == '') {
                    return false
                }
            }
            return true
        }
        if (verificar([nome, numero, modalidade]) == true) {
            for (var o = 0; o <= 10; o++) {
                numero = numero.replace(" ", "")
                numero = numero.replace("-", "")
                numero = numero.replace("+", "")
            }
            if (!numero.includes('55')) {
                numero = numero + '55'
            }
            carregando()
            await fetch(link + "adicionar_usuario", {
                method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
                    modalidade: modalidade,
                    numero: numero,
                    nome: nome
                })
            }).catch(() => {
                alert("Api offline")
            })
            naocarregando()
        } else {
            alert("Informações incompletas.")
        }
    })

    let nomes_itens = [
        ['mensalidades', 'flex']
    ];

    for (const v of document.querySelectorAll("#opcao_menu")) {
        v.addEventListener("click", () => {
            const alt = v.getAttribute('alt');
            const elemento = document.querySelector('#' + alt);
            const index = nomes_itens.findIndex(item => item[0] === alt);

            if (index !== -1) {
                elemento.style.display = nomes_itens[index][1];
            } else {
                elemento.style.display = 'none';
            }
        });
    }
}